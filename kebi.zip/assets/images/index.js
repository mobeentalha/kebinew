import Logo from './logo.jpg'
import Back from './back2.jpg'
import BackF from './backf.jpg'
import ImageF from './kebi.png'
import ApplePay from './icons/apple-pay.png'
import GiftCard from './icons/gift-card.png'
import Pay from './icons/pay.png'
import PayPal from './icons/paypal.png'
import GoogleIcon from './google.png'
import FacebookIcon from './facebook.png'

export {Logo, Back, BackF, ImageF, ApplePay, GiftCard, Pay, PayPal, GoogleIcon, FacebookIcon}