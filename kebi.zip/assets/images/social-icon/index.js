import FB from './FB.png';
import IG from './IG.png';
import LK from './LK.png';
import TW from './TW.png';
import YT from './YT.png';

export {FB, IG, LK, TW, YT}